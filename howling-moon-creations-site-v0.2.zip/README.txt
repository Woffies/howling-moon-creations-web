Upload everything in this folder to the root of your GitHub repo.
Main page: index.html
Logo assets: assets/hmc-logo-main.webp and assets/hmc-logo-icon.webp
